# Plataforma Mentor
Proyecto base con Next.js y Supabase.