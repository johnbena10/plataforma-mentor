export default function Home() {
  return <h1>Bienvenido a Plataforma Mentor</h1>;
}